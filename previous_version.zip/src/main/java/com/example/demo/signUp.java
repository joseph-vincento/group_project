package com.example.demo;
import lombok.Data;
@Data
public class signUp {
    private String fName;
    private String lName;
    private String email;
    private int phone;
    private String streetAddress;
    private String city;
    private int zipCode;
    private String education;
    private long id;
}
