package com.example.demo;

import java.util.regex.Pattern;

public class EmailValidityService {

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
    "^[A-Za-z0-9+_-]+(?:\\.[A-Za-z0-9+_-]+)*@(?:[A-Za-z0-9-]+\\.)+[A-Za-z]{2,}$"
    );


    public boolean isValid(String email) {
        return EMAIL_PATTERN.matcher(email).matches();
    }
}
