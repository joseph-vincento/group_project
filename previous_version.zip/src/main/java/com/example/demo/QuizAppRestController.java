package com.example.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api") // Common base route for API endpoints
public class QuizAppRestController {

    private final PasswordQualityService passwordQualityService = new PasswordQualityService();
    private final EmailValidityService emailValidityService = new EmailValidityService();
    // Removed instantiation of QuestionBank since it's supposed to be used statically.

    @PostMapping("/password/quality")
    public ResponseEntity<Integer> checkPasswordQuality(@RequestParam String password) {
        int quality = passwordQualityService.assessQuality(password);
        return ResponseEntity.ok(quality);
    }

    @GetMapping("/email/validity")
    public ResponseEntity<Boolean> checkEmailValidity(@RequestParam String email) {
        boolean isValid = emailValidityService.isValid(email);
        return ResponseEntity.ok(isValid);
    }

    @GetMapping("/questions")
    public ResponseEntity<List<Question>> getQuestions() {
        return ResponseEntity.ok(QuestionBank.getAllQuestions()); // Updated to use static method.
    }

    
}
