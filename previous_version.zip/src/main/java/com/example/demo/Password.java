package com.example.demo;

public record Password(int len, String pwd) { }
