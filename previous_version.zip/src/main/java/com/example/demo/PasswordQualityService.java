package com.example.demo;
public class PasswordQualityService {

    public int assessQuality(String password) {
        if (password == null) {
            return 0;
        }

        int score = 0;
        if (password.length() >= 8) score += 1;
        if (password.matches(".*[0-9]+.*")) score += 1;
        if (password.matches(".*[a-z]+.*")) score += 1;
        if (password.matches(".*[A-Z]+.*")) score += 1;
        if (password.matches(".*[!@#$%^&*]+.*")) score += 1;
        return score;
    }
}

