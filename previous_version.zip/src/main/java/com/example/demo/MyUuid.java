package com.example.demo;
import java.util.UUID;

public record MyUuid (UUID uuid) { }