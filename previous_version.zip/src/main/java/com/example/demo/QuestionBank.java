package com.example.demo;

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class QuestionBank {

    private static final List<Question> questionList = new ArrayList<>();

    static {
        // Initialize with some questions
        questionList.add(new Question("3 X 3 = 9", true));
        questionList.add(new Question("George Washington was the first president of the USA", true));
        questionList.add(new Question("20 + 20 = 40", true));
        // ... add more questions as needed
    }

    // Private constructor to prevent instantiation
    private QuestionBank() {
        throw new AssertionError("QuestionBank class should not be instantiated.");
    }

    // Method to get all questions as an unmodifiable list
    public static List<Question> getAllQuestions() {
        return Collections.unmodifiableList(questionList);
    }

    // Method to get a question by index
    public static Question getQuestion(int index) {
        if (index < 0 || index >= questionList.size()) {
            throw new IllegalArgumentException("Index out of bounds for questionList");
        }
        return questionList.get(index);
    }

    // Method to get a random question
    public static Question getRandomQuestion() {
        Random random = new Random();
        return questionList.get(random.nextInt(questionList.size()));
    }
}
